import requests
import os
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
TOKEN_URL = "https://oauth.fatsecret.com/connect/token"

# Caching the access token to avoid multiple requests
access_token_cache = {"token": None, "expires_in": 0}

def get_access_token():
    global access_token_cache

    # If we already have a valid token, return it
    if access_token_cache["token"]:
        return access_token_cache["token"]

    response = requests.post(
        TOKEN_URL,
        data={"grant_type": "client_credentials"},
        auth=(CLIENT_ID, CLIENT_SECRET),
    )

    if response.status_code == 200:
        token_data = response.json()
        access_token_cache["token"] = token_data["access_token"]
        access_token_cache["expires_in"] = token_data["expires_in"]
        return token_data["access_token"]
    else:
        return {"error": response.status_code, "message": response.text}
