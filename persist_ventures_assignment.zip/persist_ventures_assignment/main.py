from fastapi import FastAPI
from fastapi.responses import JSONResponse
from auth import get_access_token
import requests

app = FastAPI()

@app.get("/auth")
def auth():
    """Returns a valid access token"""
    token = get_access_token()
    return JSONResponse(content={"access_token": token})

@app.get("/search_food")
def search_food(food_name: str):
    """Uses the access token to search for food in FatSecret API"""
    access_token = get_access_token()
    headers = {"Authorization": f"Bearer {access_token}"}
    
    params = {
        "method": "foods.search",
        "format": "json",
        "search_expression": food_name
    }

    response = requests.get("https://platform.fatsecret.com/rest/server.api", headers=headers, params=params)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": response.status_code, "message": response.text}
